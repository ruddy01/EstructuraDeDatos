#pragma once
#include "Cuadrado.h"   //  Vinculo con el header de la clase
#include <iostream>     // Manejo de iteraccion
#include "msclr\marshal_cppstd.h"  //Manejar texto

namespace AreaCuadradin {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;    // Incluir para manejar iteraccion
	using namespace msclr;  // Manejar texto


	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblLado;
	private: System::Windows::Forms::Label^  lblArea;
	private: System::Windows::Forms::TextBox^  txtLado;
	private: System::Windows::Forms::TextBox^  txtArea;
	private: System::Windows::Forms::Button^  btnCalcular;
	protected: 





	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblLado = (gcnew System::Windows::Forms::Label());
			this->lblArea = (gcnew System::Windows::Forms::Label());
			this->txtLado = (gcnew System::Windows::Forms::TextBox());
			this->txtArea = (gcnew System::Windows::Forms::TextBox());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// lblLado
			// 
			this->lblLado->AutoSize = true;
			this->lblLado->Location = System::Drawing::Point(30, 39);
			this->lblLado->Name = L"lblLado";
			this->lblLado->Size = System::Drawing::Size(40, 17);
			this->lblLado->TabIndex = 0;
			this->lblLado->Text = L"Lado";
			// 
			// lblArea
			// 
			this->lblArea->AutoSize = true;
			this->lblArea->Location = System::Drawing::Point(30, 104);
			this->lblArea->Name = L"lblArea";
			this->lblArea->Size = System::Drawing::Size(38, 17);
			this->lblArea->TabIndex = 1;
			this->lblArea->Text = L"Area";
			this->lblArea->Click += gcnew System::EventHandler(this, &Form1::label2_Click);
			// 
			// txtLado
			// 
			this->txtLado->Location = System::Drawing::Point(137, 39);
			this->txtLado->Name = L"txtLado";
			this->txtLado->Size = System::Drawing::Size(100, 22);
			this->txtLado->TabIndex = 2;
			// 
			// txtArea
			// 
			this->txtArea->Location = System::Drawing::Point(137, 101);
			this->txtArea->Name = L"txtArea";
			this->txtArea->Size = System::Drawing::Size(100, 22);
			this->txtArea->TabIndex = 3;
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(76, 179);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(75, 23);
			this->btnCalcular->TabIndex = 4;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(282, 253);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->txtArea);
			this->Controls->Add(this->txtLado);
			this->Controls->Add(this->lblArea);
			this->Controls->Add(this->lblLado);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
	
			 Cuadrado cuadradito;   // Crea el objeto cuadradito instancia
			 cuadradito.Set_lado(System::Convert::ToInt32(txtLado->Text));
			 int areafin;
			 areafin=cuadradito.Calcular();
			 txtArea->Text=System::Convert::ToString(areafin);
		 }
};
}

