#pragma once
class Cuadrado

{
private:      //Atributos
	int lado;
	int area;

public:    // metodos
	Cuadrado(void);       //Constructor
	//metodos de acceso
	//para accesar o revisar el contenido de los atributos
	int Get_lado();
	int Get_area();

	//Para darle valor a los atributos
	void Set_lado(int l);
	void Set_area(int a);

	//Operaciones especificas
	int Calcular();
};

