#include "StdAfx.h"
#include "Cuadrado.h"  //  Header de la clase- Template


Cuadrado::Cuadrado(void)
{
}

//para accesar o revisar el contenido de los atributos
int Cuadrado::Get_lado() // pueden mostrar el valor de los atributos
{   
	return lado;
}
int Cuadrado::Get_area()
{
	return area;
}

//Para darle valor a los atributos
void Cuadrado::Set_lado(int l) // Setear o darle un valor especifico a los atributos generalmente de las pantallas
{
	lado=l;
}
void Cuadrado::Set_area(int a)
{
	area=a;
}
//Operaciones especificas
int Cuadrado::Calcular()
{
	area=lado*lado;
	return area;
		
}